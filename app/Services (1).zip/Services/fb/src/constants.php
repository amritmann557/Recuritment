<?php
/*
 * PAGE AND APP RELATED
 */
const PAGE_ID     = '178886488807094';
const APP_ID      = '225532077828789'; // App should be able to access the page. Means, app owner should have admin rights to the page
const APP_SECRET  = '56975b26c4e7bc13ddd3814328a4207c';
const PAGE_TOKEN  = 'EAADNHsdiarUBAGyQbMpRZBiuIRV1jtYvoRZCFfgfTUjV9Oi6P7qKxYvwZBUleKn2rv8oNy3hgTDGcv65HQutJAWZCel31DQSpIAQAT6MZAoOvFyzJeCedYa8BdIopKOvVl8RvDA6KyvNiuZAVdGjNoYb7eqvEcLmsZD';
//const PAGE_TOKEN  = 'EAADNHsdiarUBAJPW4VvKUmQUDamDZA57UZBIvZALtUvzNsZB4jkmKgapWirFWfMQtoujB236v3BCTiAEnt2ojuq';

/**
 * DATABASE
 */
const HOST_NAME   = 'webinfomart.netfirmsmysql.com';
const DB_NAME     = 'yofikoren';
const DB_USERNAME = 'yofikoren';
const DB_PASSWORD = 'yofikoren2016!';

/**
 * EMAIL NOTIFICATION
 */
const NOTIFY_EMAIL = '';
 ?>