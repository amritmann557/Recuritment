<?php
$fb_app_id = '423395038086088';
$fb_app_secret = '67b72de3921a33886770d4111eecb49c';
$fb_api_version = 'v2.12';
$fb_page_id = '99426254891';
$fb_scope = 'manage_pages,publish_pages';
$fb_access_token='EAAGBE1bYQ8gBAPFxgEk5XuyDOvPQcXyyl6MN0sZAjQ1v65f3Vl8H4lphyZBZClEql1EAtNgiXbTJzzzF8yamDW7TKajKCN6jYCUS4ZAYTNYx0zJerY6hZCg6pcMt4g1fFZBjOouWwC5F3ep5xGGudyEctsvoe0BI0MlhZCZBTZAUXbwZDZD';