<?php
require_once __DIR__ . '/src/Facebook/autoload.php';
require_once __DIR__ . '/config/config.php';